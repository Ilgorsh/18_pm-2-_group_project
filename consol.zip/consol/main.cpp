#include <iostream>
#include "menu.h"

using namespace std;


int main()
{
    Menu op;
    op.menu_realiz();
    return 0;
}
