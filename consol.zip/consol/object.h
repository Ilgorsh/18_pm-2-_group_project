#ifndef OBJECT_H
#define OBJECT_H
#include <iostream>
#include <map>
using namespace std;


class Object{
    protected:
        int id;
        int x, y; //Координаты по x и y, отвечающие за местополжение объекта
        bool metal, paper, glass, plastic, organic;//Массив булов для материалов
        string *s; //назвоние
    public:
        int get_number_of_types();
        Object();
};

#endif // OBJECT_H
